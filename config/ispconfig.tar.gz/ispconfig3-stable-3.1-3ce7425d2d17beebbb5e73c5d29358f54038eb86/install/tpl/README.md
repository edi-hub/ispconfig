Overriding templates
--------------------

Manually altered versions have to be put into `server/conf-custom/install/`, e.g. `/usr/local/ispconfig/server/conf-custom/install/`
